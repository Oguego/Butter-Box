# frozen_string_literal: true

require 'diff/lcs'
