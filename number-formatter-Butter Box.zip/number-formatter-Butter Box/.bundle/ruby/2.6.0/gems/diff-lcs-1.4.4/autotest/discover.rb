# frozen_string_literal: true

Autotest.add_discovery { 'rspec2' }
