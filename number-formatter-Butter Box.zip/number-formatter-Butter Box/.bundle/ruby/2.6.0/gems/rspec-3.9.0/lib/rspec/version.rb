module RSpec # :nodoc:
  module Version # :nodoc:
    STRING = '3.9.0'
  end
end
