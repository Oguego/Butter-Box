module RSpec
  module Support
    module Version
      STRING = '3.9.3'
    end
  end
end
