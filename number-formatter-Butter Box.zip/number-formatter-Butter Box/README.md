# ButterBox Ruby Test

This contain a solution to a challenge for Butter Box, solution was created using pure Ruby in a Test Drive Development

The solution goes in `lib/format_number_ruby.rb

Tests are in `spec/format_number_ruby_spec.rb`. Run them using `bundle exec rspec --format documentation` from the top level directory.

The solution was created purely in Ruby, no library or libraries used

 


