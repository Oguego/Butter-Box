#require '../lib/format_number_ruby'

require 'format_number_ruby'

RSpec.describe 'FormatNumberRuby' do

  describe ".format" do
    it 'This should returns the phone number formatted wih +44 prefix' do
      expect(FormatNumberRuby::PhoneNumber::UK.format("07 4407 04586")).to eq("+447440704586")
    end

    it 'Retuns an error messages, when a non valid UK number is not entered, as it should start with "07"' do
      expect(FormatNumberRuby::PhoneNumber::UK.format("0634343")).to eq(["ERROR:: Please enter a valid UK number"])
    end

    it 'Returns an error message, if the phone number is too longer than 13 digits' do
      expect(FormatNumberRuby::PhoneNumber::UK.format("07 4407 045868")).to eq(["Phone number is too long"])
    end

    it 'Returns an error message, of INCOMPLETE phone number, if less than 13' do
      expect(FormatNumberRuby::PhoneNumber::UK.format("07 4407 068")).to eq(["Incomplete phone number"])
    end

    it 'Returns an error message, if the phone number contains ANY characters, except "+"' do
      expect(FormatNumberRuby::PhoneNumber::UK.format("075 4 872 37l8")).to eq(["Phone numbers should not contain any characters"])
    end

  end

end


