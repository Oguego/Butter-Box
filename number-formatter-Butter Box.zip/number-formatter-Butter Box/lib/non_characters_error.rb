class NonCharactersError < StandardError
  attr_reader :error
  def initialize(msg: "Phone numbers should not contain any characters", error: "phone number should be digits only")
    @error = error
    super(msg)
  end
end
