class PhoneNumberLongError < StandardError
  attr_reader :error
  def initialize(msg: "Phone number is too long", error: "Enter accurate phone number")
    @error = error
    super(msg)
  end
end
