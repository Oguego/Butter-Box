class ValidNumberError < StandardError
  attr_reader :error
  def initialize(msg: "ERROR:: Please enter a valid UK number", error: "phone number is not valid")
    @error = error
    super(msg)
  end
end