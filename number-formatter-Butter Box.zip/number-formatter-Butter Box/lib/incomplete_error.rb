class IncompleteError < StandardError
  attr_reader :error
  def initialize(msg: "Incomplete phone number", error: "number is not complete")
    @error = error
    super(msg)
  end
end
