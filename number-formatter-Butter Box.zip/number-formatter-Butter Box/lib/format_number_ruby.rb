  module FormatNumberRuby
    module PhoneNumber
      module UK

      def self.format(number) #Class function to
          number = number.delete(' ') #Removes any whitespace(s) found in between the phone numbers

          formatted_number = "" #Creates an empty variable

          #Hash containing possible prefix(conditions) from phone numbers entered and values which should replace the prefix
          conditions = {"07" => "+447",
                        "447" => "+447",
                        "+447" => "+447",
                        "+4407" => "+447"}

          #Loop through the conditions, and replace the prefix where applicable and saves the output in the empty variable initailly created (formatted_number)
          conditions.each do |key, value|
            if number.start_with? key.to_s
              formatted_number = format_swap(number, key.to_s,  value.to_s)
            end
          end

          #Return an appropriate error messages after validations, if no messages, it will return the phone number in the right format
          error_messages = run_validations(formatted_number)
          if error_messages.any?
            #puts error_messages #Displays error message if required
            error_messages
          else
            formatted_number
          end
      end

      #Run validation on the content of the variable (formatted_number) and returns the appropriate error message
      def self.run_validations(formatted_number)
            messages = [] #Array of variable to store error messages

        begin
            if formatted_number.size < 13 && formatted_number.size > 1 #Check if the variable size is less than 13 and longer than 1
              messages << "Incomplete phone number"
              raise IncompleteError.new(msg: "This phone number is Incomplete", error: "Please enter a valid phone number")
            end
        rescue => e
          #puts e.error
        end


         begin
            if formatted_number.size > 13 #Check if the variable size is longer that 13
              messages << "Phone number is too long";
              raise PhoneNumberLongError#.new(msg: "Phone number is too long", error: "Enter accurate phone number")
            end
         rescue => e
           #puts e.error
         end


         begin
            if formatted_number.empty? #Check if the variable is empty
              messages << "ERROR:: Please enter a valid UK number";
              raise ValidNumberError.new(msg: "ERROR:: Please enter a valid UK number", error: "phone number is not valid")
            end
          rescue => e
            #puts e.error
         end


         begin
            if formatted_number =~ /[[:alpha:]]/ #Check if the variable contains any Characters
              messages << "Phone numbers should not contain any characters"
              raise NonCharactersError.new(msg: "Phone numbers should not contain any characters", error: "Phone number should only contain numbers")
            end
         rescue => e
           #puts e.error
         end



            # messages
            #   rescue StandardError => e #Rescues any error and continue processing the rest of the code
            #     puts e.inspect
            messages


      end


        #Function to replace/swap the phone number prefix(07 for example) to the right/specified format(+44)
          def self.format_swap(number, a, b)
            number.sub(a, b)
          end

      end
    end
  end

#puts ErrorDetector::FormatNumberRuby::PhoneNumber::UK.format("075 4 872 37855")